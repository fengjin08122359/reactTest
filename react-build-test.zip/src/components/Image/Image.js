import React,{ Component } from "react";
import PropTypes from "prop-types";
import { Button, Radio, Input } from 'element-react';

export default class Image extends Component{
	componentDidMount() {
	}
	render(){
		const { 
			rootPath, 
			user,
			domain,
      example,
      prePath,
      handelDomain,
      handelExample,
      handelRootPath,
      handelPrePath
		} = this.props;

		return(
			<div>
        <Input prepend="域名" onInput={handelDomain} value={domain} placeholder="" />
        <Input  prepend="网址" onInput={handelRootPath} value={rootPath} placeholder="" />
        <Input  prepend="authKey" onInput={handelPrePath} value={prePath} placeholder="" />
        <Input value={example} type='textarea' autosize={{ minRows: 15, maxRows: 15 }} placeholder='请输入内容'></Input>
        <Button onClick={() => handelExample(example)}>确定</Button>
			</div>
		)
	}
}
