import React,{ Component } from "react";
import { Router,Route,Link,browserHistory,IndexRoute } from "react-router";
import { Provider } from "react-redux";
import store from "../store";
import {
	App,
	Openfire,
	Ucc,
  Image,
  Paging
} from "./components.js"

export default class ROOT extends Component{
	render(){
		return(
			<Provider store = { store }>
				<Router history={browserHistory}>
					<Route path="/" component = { App }>
						<IndexRoute component = { Ucc } />
						<Route path="openfire" component = { Openfire }></Route>
            <Route path="ucc" component = { Ucc }></Route>
            <Route path="img" component = { Image }></Route>
					</Route>
				</Router>
			</Provider>
		);
	}
}