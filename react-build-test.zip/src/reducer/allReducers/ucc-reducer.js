export default function ucc(state = {
	httpselect: false,
  example: "",
  domain: "127.0.0.1:8080",
  webPage: "127.0.0.1:8080",
  authKey: "HYgvCfcfF5123IHHu74566666",
  webSocket: true,
  redis: true,
  browserMerge:true,
},action){
	switch(action.type){
		case "UCC_HTTPSELECT":
			return Object.assign({}, state, {
        httpselect:action.value
      })
    case "UCC_CHANGEDOMAIN":
      return Object.assign({}, state, {
        domain: action.value
      })
    case "UCC_CHANGEWEBPAGE":
      return Object.assign({}, state, {
        webPage: action.value
      })
    case "UCC_CHANGEAUTHKEY":
      return Object.assign({}, state, {
        authKey: action.value
      })
    case "UCC_CHANGEEXAMPLE":
      return Object.assign({}, state, {
        example: action.value
      })
    case "UCC_CHANGEWEBSOCKET":
			return Object.assign({}, state, {
        webSocket: action.value
      })
    case "UCC_REDIS":
      return Object.assign({}, state, {
        redis: action.value
      })
    case "UCC_BROWSERMERGE":
      return Object.assign({}, state, {
        browserMerge: action.value
      })
		// this is required
		default:
			return state;
	}
}
