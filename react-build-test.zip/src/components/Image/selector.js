import { createSelector } from 'reselect'

const getRootPath = (state) => state.images.rootPath
const getDomain = (state) => state.images.domain
const getPrePath = (state) => state.images.prePath

export const imageExample = createSelector(
  [ getRootPath, getDomain, getPrePath],
  (rootPath, domain, prePath) => {
    var textarea = "";
    textarea += "ROOT_UPLOAD_PATH:" + rootPath + "\r\n"
    textarea += "PREFIX_UPLOAD_PATH:" + prePath + "\r\n"
    textarea += "MAPPING_ROOT_PATH:" + domain + "\r\n"
    return textarea
  }
)