import count from "./allReducers/counter-reducer.js"
import ucc from "./allReducers/ucc-reducer.js"
import openfire from "./allReducers/openfire-reducer.js"
import images from "./allReducers/images-reducer.js"

export {
	count,
  ucc,
  openfire,
  images
}