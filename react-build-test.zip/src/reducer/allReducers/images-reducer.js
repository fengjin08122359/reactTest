export default function images(state = {
	rootPath: "/opt/ucc/data/",
  prePath: "file/",
  domain: "http://127.0.0.1:8080",
  example: ""
},action){
	switch(action.type){
		case "IMAGE_ROOTPATH":
			return Object.assign({}, state, {
        rootPath:action.value
      })
    case "IMAGE_PREPATH":
      return Object.assign({}, state, {
        prePath: action.value
      })
    case "IMAGE_DOMAIN":
      return Object.assign({}, state, {
        domain: action.value
      })
    case "IMAGE_EXAMPLE":
      return Object.assign({}, state, {
        example: action.value
      })
		// this is required
		default:
			return state;
	}
}
