import COUNTER_ACTIONS from "./allActions/counterAction";
import UCC_ACTIONS from "./allActions/uccAction";
import OPENFIRE_ACTIONS from "./allActions/openfireAction";
import IMAGE_ACTIONS from "./allActions/imageAction";

export{
	COUNTER_ACTIONS,
  UCC_ACTIONS,
  OPENFIRE_ACTIONS,
  IMAGE_ACTIONS
}