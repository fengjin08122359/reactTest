export default function openfire(state = {
	httpselect: false,
  example: "",
  domain: "127.0.0.1:9090",
  inside: "127.0.0.1:9090",
  outside: "127.0.0.1:9090",
},action){
	switch(action.type){
		case "OPENFIRE_HTTPSELECT":
			return Object.assign({}, state, {
        httpselect:!action.value
      })
    case "OPENFIRE_CHANGEDOMAIN":
      return Object.assign({}, state, {
        domain: action.value
      })
    case "OPENFIRE_CHANGEINSIDE":
      return Object.assign({}, state, {
        inside: action.value
      })
    case "OPENFIRE_CHANGEOUTSIDE":
      return Object.assign({}, state, {
        outside: action.value
      })
    case "OPENFIRE_CHANGEEXAMPLE":
      return Object.assign({}, state, {
        example: action.value
      })
		// this is required
		default:
			return state;
	}
}
